  (func $CPedInventoryLoadOutManager::SetLoadOut_CPed*__unsigned_int_ (type 10) (param i64 i32) (result i32)
    (local i64 i64 i64 i64 i64 i64 i32)
    global.get $__stack_pointer
    i64.const 48
    i64.sub
    local.tee 5
    global.set $__stack_pointer
    block  ;; label = @1
      block  ;; label = @2
        block  ;; label = @3
          local.get 0
          i64.eqz
          local.tee 8
          br_if 0 (;@3;)
          i64.const 18581341
          i32.load8_u
          i32.const 1
          i32.and
          i32.eqz
          br_if 0 (;@3;)
          local.get 0
          i64.load offset=4304
          i64.const 17873661021126656
          i64.and
          i64.const 3940649673949184
          i64.eq
          br_if 1 (;@2;)
          block  ;; label = @4
            i64.const 28497416
            i32.atomic.load8_u
            i32.const 1
            i32.and
            br_if 0 (;@4;)
            i64.const 28497416
            call $__cxa_guard_acquire
            i32.eqz
            br_if 0 (;@4;)
            i64.const 28497408
            i32.const -1343280487
            i32.store
            i32.const 0
            i32.const -1343280487
            i64.const 2462468
            call $rage::atHashStringNamespaceSupport::AddString_rage::atHashStringNamespaces__unsigned_int__char_const*_
            i64.const 28497416
            call $__cxa_guard_release
          end
          i64.const 28497408
          i32.load
          local.set 1
          br 1 (;@2;)
        end
        local.get 8
        i32.eqz
        br_if 0 (;@2;)
        i32.const 0
        local.set 8
        br 1 (;@1;)
      end
      i32.const 0
      local.set 8
      local.get 1
      i32.eqz
      br_if 0 (;@1;)
      local.get 0
      i64.load offset=4336
      local.tee 6
      i64.eqz
      br_if 0 (;@1;)
      block  ;; label = @2
        i64.const 28497368
        i64.load16_u
        local.tee 3
        i64.eqz
        br_if 0 (;@2;)
        i64.const 28497360
        i64.load
        local.set 4
        loop  ;; label = @3
          local.get 1
          local.get 4
          local.get 2
          i64.const 3
          i64.shl
          i64.add
          local.tee 7
          i32.load
          i32.ne
          if  ;; label = @4
            local.get 3
            local.get 2
            i64.const 1
            i64.add
            local.tee 2
            i64.ne
            br_if 1 (;@3;)
            br 2 (;@2;)
          end
        end
        local.get 7
        i32.load offset=4
        local.set 1
      end
      i64.const 0
      local.set 2
      i64.const 28497352
      i64.load16_u
      local.tee 4
      i64.eqz
      br_if 0 (;@1;)
      i64.const 28497344
      i64.load
      local.set 7
      loop  ;; label = @2
        local.get 7
        local.get 2
        i64.const 24
        i64.mul
        i64.add
        local.tee 3
        i32.load
        local.get 1
        i32.ne
        if  ;; label = @3
          local.get 4
          local.get 2
          i64.const 1
          i64.add
          local.tee 2
          i64.ne
          br_if 1 (;@2;)
          br 2 (;@1;)
        end
      end
      local.get 3
      i64.eqz
      br_if 0 (;@1;)
      i64.const 28463163
      i32.load8_u
      i32.const 5
      i32.ge_u
      if  ;; label = @2
        local.get 5
        local.get 6
        i64.load offset=16
        local.tee 4
        i64.load offset=32
        local.tee 2
        i64.eqz
        if (result i64)  ;; label = @3
          i64.const 4086926
        else
          i32.const 0
          local.get 2
          i32.load offset=24
          call $rage::atHashStringNamespaceSupport::TryGetString_rage::atHashStringNamespaces__unsigned_int_
        end
        i64.store offset=40
        local.get 5
        local.get 4
        i64.store offset=32
        i64.const 28463160
        i32.const 5
        i64.const 2305292
        local.get 5
        i64.const 32
        i64.add
        call $rage::diagLogf2_rage::diagChannel_const&__rage::diagSeverity__char_const*__..._
      end
      local.get 6
      i64.const 24
      i64.add
      call $CInventoryItemRepository<CWeaponItem__105>::RemoveAllItems__
      local.get 6
      i64.const 72
      i64.add
      call $CInventoryItemRepository<CAmmoItem__65>::RemoveAllItems__
      i64.const 28463163
      i32.load8_u
      i32.const 5
      i32.ge_u
      if  ;; label = @2
        i32.const 0
        local.get 3
        i32.load
        call $rage::atHashStringNamespaceSupport::TryGetString_rage::atHashStringNamespaces__unsigned_int_
        local.set 4
        local.get 5
        local.get 0
        i64.load offset=32
        local.tee 2
        i64.eqz
        if (result i64)  ;; label = @3
          i64.const 4086926
        else
          i32.const 0
          local.get 2
          i32.load offset=24
          call $rage::atHashStringNamespaceSupport::TryGetString_rage::atHashStringNamespaces__unsigned_int_
        end
        i64.store offset=16
        local.get 5
        local.get 0
        i64.store offset=8
        local.get 5
        local.get 4
        i64.store
        i64.const 28463160
        i32.const 5
        i64.const 2305256
        local.get 5
        call $rage::diagLogf2_rage::diagChannel_const&__rage::diagSeverity__char_const*__..._
      end
      local.get 3
      i32.load16_u offset=16
      if  ;; label = @2
        i64.const 0
        local.set 2
        loop  ;; label = @3
          local.get 3
          i64.load offset=8
          local.get 2
          i64.const 3
          i64.shl
          i64.add
          i64.load
          local.tee 4
          local.get 0
          local.get 4
          i64.load
          i64.load offset=16
          call_indirect (type 3)
          local.get 2
          i64.const 1
          i64.add
          local.tee 2
          local.get 3
          i64.load16_u offset=16
          i64.lt_u
          br_if 0 (;@3;)
        end
      end
      i32.const 1
      local.set 8
      local.get 0
      i64.load offset=4344
      local.tee 2
      i64.eqz
      br_if 0 (;@1;)
      local.get 2
      i64.load offset=104
      local.tee 3
      i64.const 0
      i64.ne
      if  ;; label = @2
        local.get 3
        i32.load offset=16
        br_if 1 (;@1;)
      end
      local.get 2
      local.get 0
      i32.load offset=5096
      i32.const -1
      i32.const 1
      i32.const 0
      i32.const 0
      call $CPedWeaponManager::EquipWeapon_unsigned_int__int__bool__bool__CPedEquippedWeapon::eAttachPoint_
      drop
    end
    local.get 5
    i64.const 48
    i64.add
    global.set $__stack_pointer
    local.get 8)
