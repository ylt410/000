"""Fetch exact small files from the user's game ZIPs using bounded HTTP ranges."""
import hashlib
import json
import struct
import zlib
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
REF = ROOT/'references'
PARTS = {p['name']: p for p in json.loads((REF/'playgta5-download-manifest.json').read_text())['parts']}
FILES = json.loads((REF/'file-inventory.json').read_text())['files']


def fetch(part, start, end):
    req = Request(part['url'] + f'?wse_range={start}-{end}', headers={
        'Range': f'bytes={start}-{end}', 'Accept-Encoding': 'identity'})
    with urlopen(req, timeout=40) as r:
        expected = f"bytes {start}-{end}/{part['bytes']}"
        if r.status != 206 or r.headers.get('Content-Range') != expected:
            raise RuntimeError((r.status, r.headers.get('Content-Range'), expected))
        data = r.read(end-start+2)
    assert len(data) == end-start+1
    return data


def directory(part):
    cache = ROOT/'base'/(part['name']+'.central.json')
    if cache.exists(): return json.loads(cache.read_text())
    tail = fetch(part, part['bytes']-65557, part['bytes']-1)
    at = tail.rfind(b'PK\x05\x06')
    assert at >= 0
    disk, cd_disk, on_disk, count, size, offset, comment = struct.unpack_from('<4H2IH', tail, at+4)
    assert disk == cd_disk == 0 and count == on_disk and size < 4000000
    cd = fetch(part, offset, offset+size-1)
    p = 0
    rows = []
    while p < len(cd):
        assert cd[p:p+4] == b'PK\x01\x02'
        v = struct.unpack_from('<6H3I5H2I', cd, p+4)
        fn, ex, co = v[9:12]
        rows.append(dict(name=cd[p+46:p+46+fn].decode(), method=v[3], crc=v[6],
                         compressed=v[7], size=v[8], offset=v[15]))
        p += 46+fn+ex+co
    assert len(rows) == count
    cache.parent.mkdir(exist_ok=True)
    cache.write_text(json.dumps(rows, indent=2))
    return rows


def get(path):
    item = next(x for x in FILES if x['path'] == path)
    target = ROOT/'base'/path.split('/data/', 1)[1]
    if target.exists():
        assert hashlib.sha256(target.read_bytes()).hexdigest() == item['sha256']
        return
    part = PARTS[item['part']]
    entry = next(x for x in directory(part) if x['name'] == path)
    hdr = fetch(part, entry['offset'], entry['offset']+29)
    assert hdr[:4] == b'PK\x03\x04'
    fn, ex = struct.unpack_from('<HH', hdr, 26)
    offset = entry['offset']+30+fn+ex
    raw = fetch(part, offset, offset+entry['compressed']-1)
    data = raw if entry['method'] == 0 else zlib.decompress(raw, -15)
    assert len(data) == entry['size'] == item['bytes']
    assert zlib.crc32(data) & 0xffffffff == entry['crc']
    assert hashlib.sha256(data).hexdigest() == item['sha256']
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    print(target.relative_to(ROOT), len(data), item['sha256'], flush=True)


if __name__ == '__main__':
    for path in ['common/data/ai/loadouts.meta', 'common/data/dispatch.meta',
                 'x64/data/metadata/pedpersonality.ymt']:
        get('mirror/playgta5.com/data/'+path)
