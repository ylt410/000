"""Build a single, explicit-path WSE 5.0 install for the user's legacy game files."""
import copy
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from rpf_open import Rpf, personality_binding

ROOT = Path(__file__).resolve().parent
AUTHOR = ROOT/'original/wsefedpack/Files'
BASE = ROOT/'base'
OUT = ROOT/'output'
MOD = OUT/'WSE_Federal_iOS_Compat_v1.0'
ORIGINAL_SHA = 'ad5e4956af450202078e2d5868bb8179012664d768a7afb5e72c4e777056e9cc'
WEAPONS = {
    'WEAPON_TACTICALRIFLE': 'WEAPON_CARBINERIFLE',
    'WEAPON_HEAVYRIFLE': 'WEAPON_ASSAULTRIFLE',
    'WEAPON_COMBATSHOTGUN': 'WEAPON_PUMPSHOTGUN',
    'WEAPON_SMG_MK2': 'WEAPON_SMG',
    'WEAPON_CARBINERIFLE_MK2': 'WEAPON_CARBINERIFLE',
    'WEAPON_SPECIALCARBINE_MK2': 'WEAPON_SPECIALCARBINE',
    'WEAPON_PUMPSHOTGUN_MK2': 'WEAPON_PUMPSHOTGUN',
}


def sha(data): return hashlib.sha256(data).hexdigest()


def xml(data):
    return ET.tostring(data, encoding='utf-8', xml_declaration=True)+b'\n'


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def merge_loadouts():
    stock = ET.parse(BASE/'common/data/ai/loadouts.meta').getroot()
    author = ET.parse(AUTHOR/'loadouts.meta').getroot()
    target = stock.find('LoadOuts')
    names = {x.findtext('Name') for x in target}
    added, replacements = [], []
    for item in author.findall('./LoadOuts/Item'):
        name = item.findtext('Name')
        # Keep all real stock names (the author's _BRUH copies disable these on PC).
        # Existing stock definitions are unchanged; only WSE's new presets are added.
        if name in names or name.endswith('_BRUH'):
            continue
        item = copy.deepcopy(item)
        for weapon in item.findall('.//WeaponName'):
            if weapon.text in WEAPONS:
                old = weapon.text
                weapon.text = WEAPONS[old]
                replacements.append(dict(loadout=name, old=old, new=weapon.text))
        target.append(item)
        names.add(name)
        added.append(name)
    return xml(stock), added, replacements


def adapt_dispatch(data):
    root = ET.fromstring(data)
    # These newer optional emergency systems reference absent DLC vehicles/peds.
    # They are not part of WSE's police response, and do not exist in stock dispatch.
    for node in list(root.find('VehicleSets')):
        if node.findtext('Name') in {'BIKER', 'ASSASSINS'}:
            root.find('VehicleSets').remove(node)
    for parent in [root.find('DispatchOrderDistances'), root.find('EmergencyResponses')]:
        for node in list(parent):
            if node.findtext('DispatchType') in {'DT_BikerBackup', 'DT_Assassins'}:
                parent.remove(node)
    return xml(root)


def patch_vehicle_metadata(raw):
    root = ET.fromstring(raw)
    changes = []
    patches = {
        'fibannihilator': {'audioNameHash': 'ANNIHILATOR'},
        'ncgannihilator': {'audioNameHash': 'ANNIHILATOR'},
        'usmarshcruiser': {'audioNameHash': 'POLICE'},
        'ncgpatrolboat': {'handlingId': 'PREDATOR', 'layout': 'LAYOUT_BOAT_PREDATOR',
                          'audioNameHash': 'PREDATOR'},
    }
    for item in root.findall('./InitDatas/Item'):
        name = item.findtext('modelName')
        for field, value in patches.get(name, {}).items():
            element = item.find(field)
            assert element is not None
            changes.append(dict(model=name, field=field, old=element.text or '', new=value))
            element.text = value
    assert len(changes) == 6
    return xml(root), changes


def build():
    original = ROOT/'WSE_Federal_Enforcement_original.zip'
    assert sha(original.read_bytes()) == ORIGINAL_SHA
    if not (AUTHOR/'wsefed/dlc.rpf').exists():
        with zipfile.ZipFile(original) as z:
            assert all(not n.startswith('/') and '..' not in Path(n).parts for n in z.namelist())
            z.extractall(ROOT/'original')
    if MOD.exists(): shutil.rmtree(MOD)
    report = {'version': '1.0', 'upstream': 'WSE Federal Enforcement 5.0 by DonKrushko',
              'upstream_url': 'https://www.gta5-mods.com/misc/wanted-system-enhancement-federal-enforcement',
              'upstream_archive_sha256': ORIGINAL_SHA, 'device_tested': False}
    loadouts, added, replacements = merge_loadouts()
    report.update(added_loadouts=added, weapon_replacements=replacements)
    rpf_path = AUTHOR/'wsefed/dlc.rpf'
    archive = Rpf(rpf_path.read_bytes())
    vehicle_path = 'common/data/levels/gta5/vehicles.meta'
    vehicles, changes = patch_vehicle_metadata(archive.read(vehicle_path))
    report['vehicle_metadata_changes'] = changes
    pack = archive.replace({vehicle_path: vehicles})
    write(MOD/'update/x64/dlcpacks/wsefed/dlc.rpf', pack)
    write(MOD/'update/x64/dlcpacks/wsefedmap/dlc.rpf', (AUTHOR/'wsefedMap/dlc.rpf').read_bytes())
    data_paths = {
        'common/data/ai/loadouts.meta': loadouts,
        'common/data/dispatch.meta': adapt_dispatch((AUTHOR/'dispatch/Classic/dispatch.meta').read_bytes()),
        'x64/data/metadata/pedpersonality.ymt': (AUTHOR/'pedpersonality.ymt').read_bytes(),
        'x64/levels/gta5/popgroups.ymt': (AUTHOR/'popgroups.ymt').read_bytes(),
        'x64/levels/gta5/zonebind.ymt': (AUTHOR/'zonebind.ymt').read_bytes(),
        'common/data/levels/gta5/popcycle.dat': (AUTHOR/'popcycle.dat').read_bytes(),
    }
    # Use PC paths recognized by ModInstaller.gameAnchor, rather than guessed loose filenames.
    for path, data in data_paths.items(): write(MOD/'update/update.rpf'/path, data)
    report['kept'] = ['All original nested model/texture archives, byte for byte',
                      'All 19 added ped definitions plus the SWAT replacement',
                      'All 11 added vehicle definitions', 'Original map pack and population data',
                      'Author Classic 5.0 police response; removed only unrelated BIKER/ASSASSINS entries',
                      'Existing trainer script and ammo-capacity override are not included or overwritten']
    report['install_files'] = {str(p.relative_to(MOD)): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
                               for p in sorted(MOD.rglob('*')) if p.is_file()}
    OUT.mkdir(exist_ok=True)
    write(OUT/'build-report.json', (json.dumps(report, indent=2, ensure_ascii=False)+'\n').encode())
    # The .txt readme is ignored by the app's game-file installer.
    write(MOD/'安装说明.txt', README.encode('utf-8'))
    dist = ROOT/'dist'
    dist.mkdir(exist_ok=True)
    target = dist/'GTA5_WSE_Federal_iOS_Compat_v1.0.zip'
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(MOD.rglob('*')):
            if p.is_file():
                info = zipfile.ZipInfo(p.relative_to(OUT).as_posix(), (2024, 7, 30, 0, 0, 0))
                info.external_attr = 0o100644 << 16
                z.writestr(info, p.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
    print(json.dumps({'install_zip': str(target), 'bytes': target.stat().st_size,
                      'sha256': sha(target.read_bytes()), 'added_loadouts': len(added),
                      'weapon_replacements': len(replacements), 'vehicle_changes': len(changes)}, indent=2))


README = '''WSE Federal Enforcement 5.0 — iOS 兼容修复测试版 v1.0

原模组：DonKrushko
https://www.gta5-mods.com/misc/wanted-system-enhancement-federal-enforcement
本兼容改动基于用户两份 v1.4.1 日志和 alihammoud21/playgta5 的本体数据。
这是静态核对通过的实机待测版本，尚不能声称已在 iPhone 复现并消除停机。

安装：
1. 完全退出游戏。在“设置 > Mods”中删除或停用原来的 WSE/wsefedpack。
   不要让原包与这个版本同时启用：旧包会带入 backup 配置及错误的 DLC loadouts 覆盖。
   如果此前手动把旧 WSE 文件散放在 Mods 根目录，应先移走它们；不要移走自己的存档。
2. 在“设置 > Mods > 安装模组”中直接选择这个 ZIP，只启用这一份 WSE。
   压缩包已经按明确的游戏路径整理好，不需要手动选择 backup 或几个可选 dispatch。
3. 完全退出 APP 后重新打开，先试 1 星，再试 3 星、5 星。
4. 先观察地面新单位和直升机；随后靠近海边验证海岸警卫队。
   若仍停机，导出本次 native-port.log。请保留本修复包的文件名以便核对加载清单。

保留：全部新增人物和车辆模型、Classic 5.0 出警阵容、地图车辆和人口配置。
修复：使用匹配 5.0 模型的性格表；仅在原版装备表上追加 WSE 新预设，保留剧情脚本使用的
原版 LOADOUT_COP 等名称；将缺失的战术步枪/重型步枪/Mk II 武器/战斗霰弹枪换为本体已有枪；
让新增巡逻艇使用本体已有的船只布局和操控定义，补充已存在的原版车辆音效；
移除与警察出警无关、依赖新 DLC 的 BIKER/ASSASSINS 紧急事件配置。

现有警察小弟、增援、换人物等修改器继续单独保留；此包不包含 script_wasm.rpf 或 weapons.meta。
此前 v0.29 的 weapons.meta 携弹量修复仍应保留。
不需要安装 PC gameconfig.xml、ScriptHookVDotNet 或 RAGE Plugin Hook。
'''


if __name__ == '__main__': build()
