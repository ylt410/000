"""Fix the two WSE fragment resources rejected by this engine's pgBase constructor."""
import struct
import zlib

FIELDS_DESC = [(8, 4, 1), (7, 5, 3), (6, 7, 15), (5, 11, 63),
               (4, 17, 127), (3, 24, 1), (2, 25, 1), (1, 26, 1), (0, 27, 1)]
TARGETS = {'sepcruiser.yft': 0xa81c2283, 'sepcruiser_hi.yft': 0xac160583}


def pages(flags):
    base = 512 << (flags & 15)
    return [base*(1 << power) for power, shift, mask in FIELDS_DESC
            for _ in range((flags >> shift) & mask)]


def repair(name, raw):
    assert raw[:4] == b'RSC7'
    version, system, graphics = struct.unpack_from('<III', raw, 4)
    assert name in TARGETS and system == TARGETS[name]
    old_pages = pages(system)
    assert version == 162 and system & 15 == 3
    assert [p for p in old_pages if p < 8192] == [4096]
    assert graphics == 0x20000000 and not pages(graphics)
    plain = zlib.decompress(raw[16:], -15)
    assert len(plain) == sum(old_pages)
    # Remove the 4-KiB tail and carry one 8-KiB unit through the existing page fields.
    # All earlier logical data offsets and all embedded pointers stay unchanged.
    fixed = system & ~(1 << 27)
    for power, shift, mask in reversed(FIELDS_DESC[:-1]):
        count = (fixed >> shift) & mask
        if count < mask:
            fixed += 1 << shift
            break
        fixed &= ~(mask << shift)
    else:
        raise AssertionError('page flags capacity exhausted')
    new_pages = pages(fixed)
    assert min(new_pages) >= 8192 and len(new_pages) <= len(old_pages)
    assert sum(new_pages)-sum(old_pages) == 4096
    info = struct.unpack_from('<Q', plain, 8)[0]-0x50000000
    assert 0 <= info <= len(plain)-16
    # pgBase rewrites this existing page-info array. Never exceed its original capacity.
    assert len(new_pages) <= plain[info+8]+plain[info+9]
    padded = plain+b'\0'*4096
    compressor = zlib.compressobj(9, zlib.DEFLATED, -15)
    data = b'RSC7'+struct.pack('<III', version, fixed, graphics)
    data += compressor.compress(padded)+compressor.flush()
    assert zlib.decompress(data[16:], -15) == padded
    return data, {'name': name, 'old_system_flags': hex(system), 'new_system_flags': hex(fixed),
                  'old_min_page': min(old_pages), 'new_min_page': min(new_pages),
                  'old_page_count': len(old_pages), 'new_page_count': len(new_pages),
                  'padding_bytes': 4096, 'original_model_bytes_unchanged': True}
