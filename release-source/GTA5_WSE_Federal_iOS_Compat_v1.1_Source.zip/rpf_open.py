"""Read OPEN RPF7 archives; replace root binary entries without touching models."""
import struct
import zlib


class Rpf:
    def __init__(self, data):
        self.data = data
        magic, self.count, names_size, flag = struct.unpack_from('<4I', data)
        assert magic == 0x52504637 and flag == 0x4e45504f
        self.names = data[16+self.count*16:16+self.count*16+names_size]
        self.entries = {}
        self._walk(0, '')

    def _walk(self, index, parent):
        at = 16+index*16
        q = self.data[at:at+16]
        name_at = struct.unpack_from('<H', q)[0]
        name = self.names[name_at:].split(b'\0', 1)[0].decode()
        path = '/'.join(x for x in [parent, name] if x)
        a, b, c, d = struct.unpack('<4I', q)
        if b == 0x7fffff00:
            for child in range(c, c+d):
                self._walk(child, path)
            return
        size = int.from_bytes(q[2:5], 'little')
        flags_offset = int.from_bytes(q[5:8], 'little')
        resource = bool(flags_offset & 0x800000)
        offset = (flags_offset & 0x7fffff)*512
        assert path not in self.entries
        assert offset >= 16+self.count*16+len(self.names)
        assert offset+(size or c) <= len(self.data)
        self.entries[path] = dict(index=index, size=size, offset=offset,
                                  resource=resource, plain_size=c, encrypted=d)

    def raw(self, path):
        e = self.entries[path]
        return self.data[e['offset']:e['offset']+(e['size'] or e['plain_size'])]

    def read(self, path):
        e = self.entries[path]
        assert not e['resource'] and e['encrypted'] == 0
        raw = self.raw(path)
        result = zlib.decompress(raw, -15) if e['size'] else raw
        assert len(result) == e['plain_size']
        return result

    def replace(self, changes):
        result = bytearray(self.data)
        for path, plain in sorted(changes.items()):
            e = self.entries[path]
            assert not e['resource'] and e['encrypted'] == 0
            compressor = zlib.compressobj(9, zlib.DEFLATED, -15)
            raw = compressor.compress(plain)+compressor.flush()
            result.extend(b'\0'*(-len(result) % 512))
            offset = len(result)
            assert offset//512 < 0x800000 and len(raw) < 0x1000000
            at = 16+16*e['index']
            result[at+2:at+5] = len(raw).to_bytes(3, 'little')
            result[at+5:at+8] = (offset//512).to_bytes(3, 'little')
            struct.pack_into('<II', result, at+8, len(plain), 0)
            result.extend(raw)
        result.extend(b'\0'*(-len(result) % 512))
        check = Rpf(bytes(result))
        for path in self.entries:
            if path in changes: assert check.read(path) == changes[path]
            else: assert check.raw(path) == self.raw(path), path
        return bytes(result)

    def repack(self, *, plain_changes=None, stored_changes=None, resource_changes=None):
        """Compact OPEN RPF, retaining every unrelated entry's stored payload verbatim."""
        plain_changes = plain_changes or {}
        stored_changes = stored_changes or {}
        resource_changes = resource_changes or {}
        touched = set(plain_changes) | set(stored_changes) | set(resource_changes)
        assert touched <= self.entries.keys()
        assert len(touched) == len(plain_changes)+len(stored_changes)+len(resource_changes)
        first = min(e['offset'] for e in self.entries.values())
        result = bytearray(self.data[:first])
        expected = {}
        for path, e in sorted(self.entries.items(), key=lambda item: item[1]['offset']):
            data = self.raw(path)
            size, a, b = e['size'], e['plain_size'], e['encrypted']
            if path in plain_changes:
                assert not e['resource'] and b == 0
                plain = plain_changes[path]
                comp = zlib.compressobj(9, zlib.DEFLATED, -15)
                data = comp.compress(plain)+comp.flush()
                size, a = len(data), len(plain)
            elif path in stored_changes:
                assert not e['resource'] and not size and b == 0
                data = stored_changes[path]
                a = len(data)
            elif path in resource_changes:
                assert e['resource']
                data = resource_changes[path]
                assert data[:4] == b'RSC7'
                a, b = struct.unpack_from('<II', data, 8)
                size = len(data)
            result.extend(b'\0'*(-len(result) % 512))
            offset = len(result)//512
            assert offset < 0x800000 and size < 0x1000000
            if e['resource']: offset |= 0x800000
            at = 16+16*e['index']
            result[at+2:at+5] = size.to_bytes(3, 'little')
            result[at+5:at+8] = offset.to_bytes(3, 'little')
            struct.pack_into('<II', result, at+8, a, b)
            result.extend(data)
            expected[path] = data
        result.extend(b'\0'*(-len(result) % 512))
        check = Rpf(bytes(result))
        for path, data in expected.items(): assert check.raw(path) == data, path
        return bytes(result)


def hashes(text):
    v = 0
    for b in text.lower().encode():
        v = (v+b) & 0xffffffff
        v = (v+(v << 10)) & 0xffffffff
        v ^= v >> 6
    v = (v+(v << 3)) & 0xffffffff
    v ^= v >> 11
    return (v+(v << 15)) & 0xffffffff


def personality_binding(data, name, loadout_names):
    """Resolve the adjacent big-endian Name/LoadOut hashes in the actual PSIN data."""
    assert data[:4] == b'PSIN'
    size = struct.unpack_from('>I', data, 4)[0]
    needle = struct.pack('>I', hashes(name))
    choices = {hashes(x): x for x in loadout_names}
    matches = []
    at = data.find(needle, 8, size)
    while at >= 0:
        value = struct.unpack_from('>I', data, at+4)[0]
        if value in choices: matches.append((at, choices[value]))
        at = data.find(needle, at+4, size)
    assert len(matches) == 1, (name, matches)
    return matches[0]
