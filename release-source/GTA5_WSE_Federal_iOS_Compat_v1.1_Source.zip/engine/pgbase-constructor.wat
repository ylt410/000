  (func $rage::pgBase::pgBase__ (type 0) (param i64) (result i64)
    (local i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i32)
    global.get $__stack_pointer
    i64.const 16
    i64.sub
    local.tee 5
    global.set $__stack_pointer
    local.get 0
    i64.const 4146160
    i64.store
    block  ;; label = @1
      block  ;; label = @2
        block  ;; label = @3
          global.get $GOT.data.internal.rage::datResource_sm_Current
          local.tee 8
          i64.load
          local.tee 3
          i64.eqz
          br_if 0 (;@3;)
          local.get 0
          i64.load offset=8
          local.tee 4
          i64.eqz
          br_if 0 (;@3;)
          local.get 3
          i64.const 24
          i64.add
          local.tee 1
          local.get 3
          i64.load8_u offset=4120
          local.tee 2
          i64.const 4
          i64.shl
          i64.add
          local.set 9
          local.get 2
          i64.const 0
          i64.ne
          if  ;; label = @4
            loop  ;; label = @5
              local.get 1
              local.get 1
              local.get 2
              i64.const 1
              i64.shr_u
              local.tee 6
              i64.const 4
              i64.shl
              i64.add
              local.tee 7
              i64.const 16
              i64.add
              local.get 7
              i64.load
              local.get 7
              i64.load offset=8
              i64.const 72057594037927935
              i64.and
              i64.add
              local.get 4
              i64.gt_u
              local.tee 10
              select
              local.set 1
              local.get 6
              local.get 2
              local.get 6
              i64.const -1
              i64.xor
              i64.add
              local.get 10
              select
              local.tee 2
              i64.const 0
              i64.ne
              br_if 0 (;@5;)
            end
          end
          local.get 0
          block (result i64)  ;; label = @4
            block  ;; label = @5
              local.get 1
              local.get 9
              i64.eq
              br_if 0 (;@5;)
              local.get 4
              local.get 1
              i64.load
              local.tee 2
              i64.lt_u
              br_if 0 (;@5;)
              local.get 4
              local.get 2
              local.get 1
              i64.load offset=8
              local.tee 1
              i64.const 72057594037927935
              i64.and
              i64.add
              i64.ge_u
              br_if 0 (;@5;)
              local.get 3
              i64.load
              local.get 1
              i64.const 56
              i64.shr_u
              i64.const 24
              i64.mul
              i64.add
              local.tee 1
              i64.load offset=24
              local.get 1
              i64.load offset=16
              i64.sub
              br 1 (;@4;)
            end
            local.get 3
            i64.load offset=16
            local.set 1
            local.get 5
            local.get 4
            i64.store offset=8
            local.get 5
            local.get 1
            i64.store
            i64.const 1322386
            local.get 5
            call $Quitf_int__char_const*__..._
            local.get 8
            i64.load
            local.set 3
            i64.const 0
          end
          local.get 4
          i64.add
          local.tee 1
          i64.store offset=8
          local.get 3
          i64.load
          local.set 2
          block  ;; label = @4
            local.get 1
            i64.const 0
            i64.ne
            if  ;; label = @5
              local.get 1
              i32.load8_u offset=11
              i32.eqz
              br_if 1 (;@4;)
            end
            i64.const 0
            local.set 1
          end
          local.get 1
          local.get 2
          i32.load8_u
          i32.store8 offset=8
          local.get 1
          local.get 2
          i32.load8_u offset=1
          local.tee 10
          i32.store8 offset=9
          local.get 2
          i32.load8_u
          local.set 11
          local.get 2
          i32.load8_u offset=2
          local.set 12
          local.get 1
          i32.const 0
          i32.store8 offset=11
          local.get 1
          local.get 12
          i32.store8 offset=10
          local.get 10
          local.get 11
          i32.add
          local.tee 10
          i32.eqz
          br_if 1 (;@2;)
          local.get 1
          i64.const 16
          i64.add
          local.set 4
          local.get 2
          i64.const 16
          i64.add
          local.set 7
          local.get 10
          i64.extend_i32_u
          local.set 3
          i64.const 0
          local.set 1
          loop  ;; label = @4
            i32.const 0
            local.set 10
            local.get 7
            local.get 1
            i64.const 24
            i64.mul
            i64.add
            local.tee 2
            i64.load offset=16
            i64.const 13
            i64.shr_u
            i32.wrap_i64
            local.tee 11
            i32.const 0
            i32.lt_s
            br_if 3 (;@1;)
            local.get 2
            i64.load offset=8
            local.set 2
            loop  ;; label = @5
              local.get 10
              local.tee 13
              i32.const 1
              i32.add
              local.set 10
              local.get 11
              i32.const 1
              i32.shl
              local.tee 12
              i32.const 1
              i32.or
              local.set 11
              local.get 12
              i32.const 0
              i32.ge_s
              br_if 0 (;@5;)
            end
            i32.const 30
            local.get 13
            i32.sub
            local.tee 10
            i32.const 16
            i32.ge_u
            br_if 3 (;@1;)
            local.get 10
            i64.extend_i32_u
            local.tee 6
            local.get 2
            i64.and
            i64.const 0
            i64.ne
            br_if 3 (;@1;)
            local.get 4
            local.get 1
            i64.const 3
            i64.shl
            i64.add
            local.get 2
            local.get 6
            i64.or
            i64.store
            local.get 1
            i64.const 1
            i64.add
            local.tee 1
            local.get 3
            i64.ne
            br_if 0 (;@4;)
          end
          br 1 (;@2;)
        end
        local.get 0
        i64.const 0
        i64.store offset=8
      end
      local.get 5
      i64.const 16
      i64.add
      global.set $__stack_pointer
      local.get 0
      return
    end
    unreachable)
