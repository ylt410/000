  (func $CPedInventoryLoadOutManager::SetDefaultLoadOut_CPed*__CPedModelInfo_const*_ (type 3) (param i64 i64)
    (local i64 i32)
    block  ;; label = @1
      i64.const 28497400
      i32.atomic.load8_u
      i32.const 1
      i32.and
      br_if 0 (;@1;)
      i64.const 28497400
      call $__cxa_guard_acquire
      i32.eqz
      br_if 0 (;@1;)
      i64.const 28497396
      i32.const -1343280487
      i32.store
      i32.const 0
      i32.const -1343280487
      i64.const 2462468
      call $rage::atHashStringNamespaceSupport::AddString_rage::atHashStringNamespaces__unsigned_int__char_const*_
      i64.const 28497400
      call $__cxa_guard_release
    end
    i64.const 28497396
    local.set 2
    block  ;; label = @1
      block  ;; label = @2
        local.get 0
        i64.eqz
        br_if 0 (;@2;)
        local.get 0
        i64.load offset=4304
        i64.const 17873661021126656
        i64.and
        i64.const 3940649673949184
        i64.ne
        br_if 0 (;@2;)
        local.get 1
        i64.eqz
        if  ;; label = @3
          local.get 0
          i64.load offset=32
          local.tee 1
          i64.eqz
          br_if 1 (;@2;)
        end
        local.get 1
        i32.load16_s offset=330
        local.tee 3
        i64.const 19658944
        i32.load16_u
        i32.ge_u
        br_if 1 (;@1;)
        i64.const 19658936
        i64.load
        local.get 3
        i64.extend_i32_u
        i64.const 184
        i64.mul
        i64.add
        i64.const 4
        i64.add
        local.set 2
      end
      local.get 0
      local.get 2
      i32.load
      call $CPedInventoryLoadOutManager::SetLoadOut_CPed*__unsigned_int_
      drop
      return
    end
    unreachable)
