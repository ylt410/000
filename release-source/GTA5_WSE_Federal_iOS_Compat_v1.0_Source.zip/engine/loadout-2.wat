  (func $CLoadOutWeapon::AddToPed_CPed*__const (type 3) (param i64 i64)
    (local i64 i64 i64 i64 i32 i32 i32 i32 i32 i32)
    global.get $__stack_pointer
    i64.const 80
    i64.sub
    local.tee 3
    global.set $__stack_pointer
    i64.const 28463163
    i32.load8_u
    i32.const 5
    i32.ge_u
    if  ;; label = @1
      i32.const 0
      local.get 0
      i32.load offset=8
      call $rage::atHashStringNamespaceSupport::TryGetString_rage::atHashStringNamespaces__unsigned_int_
      local.set 2
      local.get 3
      i64.const -64
      i64.sub
      local.get 1
      i64.load offset=32
      local.tee 4
      i64.eqz
      if (result i64)  ;; label = @2
        i64.const 4086926
      else
        i32.const 0
        local.get 4
        i32.load offset=24
        call $rage::atHashStringNamespaceSupport::TryGetString_rage::atHashStringNamespaces__unsigned_int_
      end
      i64.store
      local.get 3
      local.get 1
      i64.store offset=56
      local.get 3
      local.get 2
      i64.store offset=48
      i64.const 28463160
      i32.const 5
      i64.const 2305209
      local.get 3
      i64.const 48
      i64.add
      call $rage::diagLogf2_rage::diagChannel_const&__rage::diagSeverity__char_const*__..._
    end
    local.get 0
    i32.load offset=16
    local.set 6
    block  ;; label = @1
      block  ;; label = @2
        block  ;; label = @3
          i64.const 28501281
          i32.load8_u
          i32.const 1
          i32.eq
          if  ;; label = @4
            local.get 6
            i32.const 8
            i32.and
            i32.eqz
            br_if 1 (;@3;)
            i64.const 28463163
            i32.load8_u
            i32.const 5
            i32.lt_u
            br_if 2 (;@2;)
            i64.const 28463160
            i32.const 5
            i64.const 53902
            i64.const 0
            call $rage::diagLogf2_rage::diagChannel_const&__rage::diagSeverity__char_const*__..._
            br 2 (;@2;)
          end
          local.get 6
          i32.const 16
          i32.and
          i32.eqz
          br_if 0 (;@3;)
          i64.const 28463163
          i32.load8_u
          i32.const 5
          i32.lt_u
          br_if 1 (;@2;)
          i64.const 28463160
          i32.const 5
          i64.const 53951
          i64.const 0
          call $rage::diagLogf2_rage::diagChannel_const&__rage::diagSeverity__char_const*__..._
          br 1 (;@2;)
        end
        i64.const 0
        local.set 2
        block  ;; label = @3
          local.get 1
          i64.load offset=4336
          local.get 0
          i32.load offset=8
          local.get 0
          i32.load offset=12
          call $CPedInventory::AddWeaponAndAmmo_unsigned_int__int_
          i64.const 0
          i64.ne
          br_if 0 (;@3;)
          i64.const 28463163
          i32.load8_u
          i32.const 5
          i32.lt_u
          br_if 0 (;@3;)
          i64.const 28463160
          i32.const 5
          i64.const 2006220
          i64.const 0
          call $rage::diagLogf2_rage::diagChannel_const&__rage::diagSeverity__char_const*__..._
        end
        local.get 0
        i32.load16_u offset=32
        if  ;; label = @3
          loop  ;; label = @4
            local.get 1
            i64.load offset=4336
            i64.const 24
            i64.add
            local.get 0
            i32.load offset=8
            local.get 0
            i64.load offset=24
            local.get 2
            i64.const 2
            i64.shl
            i64.add
            i32.load
            call $CWeaponItemRepository::AddComponent_unsigned_int__unsigned_int_
            drop
            local.get 2
            i64.const 1
            i64.add
            local.tee 2
            local.get 0
            i64.load16_u offset=32
            i64.lt_u
            br_if 0 (;@4;)
          end
        end
        block  ;; label = @3
          local.get 0
          i32.load offset=8
          local.tee 10
          i32.eqz
          br_if 0 (;@3;)
          i64.const 28496584
          i32.load16_u
          local.tee 11
          i32.eqz
          br_if 0 (;@3;)
          local.get 11
          i32.const 1
          i32.sub
          local.set 7
          i64.const 28496576
          i64.load
          local.set 2
          loop  ;; label = @4
            local.get 7
            local.get 8
            i32.add
            i32.const 1
            i32.shr_s
            local.tee 6
            local.get 11
            i32.ge_u
            br_if 3 (;@1;)
            local.get 2
            local.get 6
            i64.extend_i32_u
            i64.const 3
            i64.shl
            i64.add
            i64.load
            local.tee 4
            i32.load offset=16
            local.tee 9
            local.get 10
            i32.ne
            if  ;; label = @5
              local.get 8
              local.get 6
              i32.const 1
              i32.add
              local.get 9
              local.get 10
              i32.gt_u
              local.tee 9
              select
              local.tee 8
              local.get 6
              i32.const 1
              i32.sub
              local.get 7
              local.get 9
              select
              local.tee 7
              i32.le_s
              br_if 1 (;@4;)
              br 2 (;@3;)
            end
          end
          local.get 4
          i64.eqz
          br_if 0 (;@3;)
          block  ;; label = @4
            block  ;; label = @5
              local.get 1
              i64.eqz
              br_if 0 (;@5;)
              local.get 1
              i32.load8_u offset=4304
              i32.const 2
              i32.and
              i32.eqz
              br_if 0 (;@5;)
              local.get 1
              i64.load offset=4336
              local.tee 2
              i64.eqz
              br_if 0 (;@5;)
              local.get 2
              local.get 10
              call $CPedInventory::GetWeapon_unsigned_int_
              local.tee 2
              i64.eqz
              br_if 0 (;@5;)
              local.get 2
              i64.load offset=88
              local.tee 2
              i64.const 0
              i64.ne
              br_if 1 (;@4;)
            end
            local.get 4
            i64.load offset=96
            local.tee 2
            i64.eqz
            br_if 1 (;@3;)
          end
          local.get 2
          i32.load offset=60
          i32.const 0
          i32.le_s
          br_if 0 (;@3;)
          local.get 1
          i64.load offset=4336
          local.tee 4
          i64.const 72
          i64.add
          local.get 2
          i32.load offset=16
          local.tee 6
          local.get 0
          i32.load offset=12
          local.tee 7
          local.get 4
          i64.load offset=16
          call $CAmmoItemRepository::AddAmmo_unsigned_int__int__CPed_const*_
          i64.eqz
          br_if 0 (;@3;)
          i64.const 28463163
          i32.load8_u
          i32.const 5
          i32.lt_u
          br_if 0 (;@3;)
          i32.const 0
          local.get 6
          call $rage::atHashStringNamespaceSupport::TryGetString_rage::atHashStringNamespaces__unsigned_int_
          local.set 2
          local.get 3
          local.get 4
          i64.load offset=16
          local.tee 4
          i64.load offset=32
          local.tee 5
          i64.eqz
          if (result i64)  ;; label = @4
            i64.const 4086926
          else
            i32.const 0
            local.get 5
            i32.load offset=24
            call $rage::atHashStringNamespaceSupport::TryGetString_rage::atHashStringNamespaces__unsigned_int_
          end
          i64.store offset=32
          local.get 3
          local.get 4
          i64.store offset=24
          local.get 3
          local.get 7
          i32.store offset=16
          local.get 3
          local.get 2
          i64.store offset=8
          local.get 3
          local.get 6
          i32.store
          i64.const 28463160
          i32.const 5
          i64.const 2305455
          local.get 3
          call $rage::diagLogf2_rage::diagChannel_const&__rage::diagSeverity__char_const*__..._
        end
        i32.const 1
        local.set 6
        block  ;; label = @3
          local.get 0
          i32.load offset=16
          local.tee 7
          i32.const 1
          i32.and
          if  ;; label = @4
            local.get 1
            i64.load offset=4344
            local.get 0
            i32.load offset=8
            i32.const -1
            local.get 1
            i32.load8_u offset=5291
            i32.const 64
            i32.and
            if (result i32)  ;; label = @5
              local.get 1
              i64.load offset=5576
              i64.eqz
            else
              local.get 6
            end
            i32.const 0
            i32.const 0
            call $CPedWeaponManager::EquipWeapon_unsigned_int__int__bool__bool__CPedEquippedWeapon::eAttachPoint_
            drop
            br 1 (;@3;)
          end
          local.get 7
          i32.const 2
          i32.and
          i32.eqz
          br_if 0 (;@3;)
          local.get 1
          i64.load offset=4344
          local.get 0
          i32.load offset=8
          i32.const -1
          i32.const 0
          i32.const 0
          i32.const 0
          call $CPedWeaponManager::EquipWeapon_unsigned_int__int__bool__bool__CPedEquippedWeapon::eAttachPoint_
          drop
        end
        local.get 0
        i32.load8_u offset=16
        i32.const 4
        i32.and
        i32.eqz
        br_if 0 (;@2;)
        local.get 1
        i64.load offset=4336
        local.tee 1
        i64.load offset=16
        local.set 4
        block  ;; label = @3
          local.get 0
          i32.load offset=8
          local.tee 10
          if  ;; label = @4
            i64.const 0
            local.set 0
            i64.const 28496584
            i32.load16_u
            local.tee 11
            i32.eqz
            br_if 1 (;@3;)
            local.get 11
            i32.const 1
            i32.sub
            local.set 7
            i64.const 28496576
            i64.load
            local.set 2
            i32.const 0
            local.set 8
            loop  ;; label = @5
              local.get 7
              local.get 8
              i32.add
              i32.const 1
              i32.shr_s
              local.tee 6
              local.get 11
              i32.ge_u
              br_if 4 (;@1;)
              local.get 10
              local.get 2
              local.get 6
              i64.extend_i32_u
              i64.const 3
              i64.shl
              i64.add
              i64.load
              local.tee 0
              i32.load offset=16
              local.tee 9
              i32.eq
              br_if 2 (;@3;)
              local.get 8
              local.get 6
              i32.const 1
              i32.add
              local.get 9
              local.get 10
              i32.gt_u
              local.tee 9
              select
              local.tee 8
              local.get 6
              i32.const 1
              i32.sub
              local.get 7
              local.get 9
              select
              local.tee 7
              i32.le_s
              br_if 0 (;@5;)
            end
          end
          i64.const 0
          local.set 0
        end
        local.get 1
        i64.const 72
        i64.add
        local.get 0
        i32.const 1
        local.get 4
        call $CAmmoItemRepository::SetWeaponUsingInfiniteAmmo_CWeaponInfo_const*__bool__CPed_const*_
      end
      local.get 3
      i64.const 80
      i64.add
      global.set $__stack_pointer
      return
    end
    unreachable)
