"""Check the final ZIP's actual resource and metadata dependency closure."""
import hashlib
import json
import struct
import unittest
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from rpf_open import Rpf, personality_binding
from resource_pages import pages
from engine_constructor import execute
import zlib

ROOT = Path(__file__).resolve().parent
AUTHOR = ROOT/'original/wsefedpack/Files'
PREFIX = 'WSE_Federal_iOS_Compat_v1.1/'
ARCHIVE = ROOT/'dist/GTA5_WSE_Federal_iOS_Compat_v1.1.zip'


def signature(e):
    return e.tag, sorted(e.attrib.items()), (e.text or '').strip(), tuple(signature(x) for x in e)


class CompatChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with zipfile.ZipFile(ARCHIVE) as z:
            assert z.testzip() is None
            cls.files = {n.removeprefix(PREFIX): z.read(n) for n in z.namelist()}
        cls.pack = Rpf(cls.files['update/x64/dlcpacks/wsefed/dlc.rpf'])
        cls.old = Rpf((AUTHOR/'wsefed/dlc.rpf').read_bytes())
        cls.loadouts = ET.fromstring(cls.files['update/update.rpf/common/data/ai/loadouts.meta'])
        cls.stock = ET.parse(ROOT/'base/common/data/ai/loadouts.meta').getroot()
        cls.names = {x.findtext('Name') for x in cls.loadouts.findall('./LoadOuts/Item')}
        cls.personality = cls.files['update/update.rpf/x64/data/metadata/pedpersonality.ymt']
        cls.peds = ET.fromstring(cls.pack.read('common/data/peds.meta'))
        cls.vehicles = ET.fromstring(cls.pack.read('common/data/levels/gta5/vehicles.meta'))
        cls.dispatch = ET.fromstring(cls.files['update/update.rpf/common/data/dispatch.meta'])

    def test_01_old_installed_backup_has_broken_new_ped_bindings(self):
        old = (AUTHOR/'backup/pedpersonality.ymt').read_bytes()
        broken = []
        for ped in self.peds.findall('./InitDatas/Item'):
            try: personality_binding(old, ped.findtext('Personality'), self.names)
            except AssertionError: broken.append(ped.findtext('Name'))
        self.assertEqual(len(broken), 7)
        self.assertIn('S_M_Y_FIBSec_01', broken)
        # The target engine explicitly traps for an invalid personality index.
        body = (ROOT/'engine/loadout-0.wat').read_text()
        self.assertIn('i32.load16_s offset=330', body)
        self.assertIn('i64.const 184', body)
        self.assertTrue(body.rstrip().endswith('unreachable)'))

    def test_02_all_new_ped_personalities_resolve_to_registered_loadouts(self):
        for ped in self.peds.findall('./InitDatas/Item'):
            with self.subTest(ped=ped.findtext('Name')):
                _, loadout = personality_binding(self.personality, ped.findtext('Personality'), self.names)
                self.assertIn(loadout, self.names)
        self.assertEqual(self.personality, (AUTHOR/'pedpersonality.ymt').read_bytes())
        for personality in ['SWAT', 'POLICE', 'POLICE_FEMALE']:
            personality_binding(self.personality, personality, self.names)

    def test_03_real_stock_loadout_names_and_definitions_are_preserved(self):
        stock = {x.findtext('Name'): x for x in self.stock.findall('./LoadOuts/Item')}
        final = {x.findtext('Name'): x for x in self.loadouts.findall('./LoadOuts/Item')}
        self.assertEqual(len(final), len(stock)+13)
        self.assertEqual(len(final), len(self.names))
        for name, item in stock.items(): self.assertEqual(signature(item), signature(final[name]), name)
        self.assertIn('LOADOUT_COP', final)
        self.assertFalse(any(x.endswith('_BRUH') for x in final))

    def test_04_all_weapon_and_component_references_exist_in_stock_data(self):
        w = ET.parse(ROOT/'base/common/data/ai/weapons.meta').getroot()
        c = ET.parse(ROOT/'base/common/data/ai/weaponcomponents.meta').getroot()
        known_weapons = {x.text for x in w.findall('.//Item/Name')} | {x.text for x in self.stock.findall('.//WeaponName')}
        known_components = {x.text for x in c.findall('.//Name')} | {x.text for x in self.stock.findall('.//ComponentNames/Item')}
        used_weapons = {x.text for x in self.loadouts.findall('.//WeaponName')}
        used_components = {x.text for x in self.loadouts.findall('.//ComponentNames/Item')}
        self.assertEqual(used_weapons-known_weapons, set())
        self.assertEqual(used_components-known_components, set())
        self.assertFalse(any('MK2' in x or x in {'WEAPON_TACTICALRIFLE', 'WEAPON_HEAVYRIFLE', 'WEAPON_COMBATSHOTGUN'} for x in used_weapons))

    def test_05_model_archives_and_nonvehicle_metadata_are_unchanged(self):
        self.assertEqual(set(self.old.entries), set(self.pack.entries))
        changed = []
        for name in self.old.entries:
            if self.old.raw(name) != self.pack.raw(name): changed.append(name)
        self.assertEqual(set(changed), {'common/data/levels/gta5/vehicles.meta',
                                       'x64/levels/gta5/vehicles/vehicles.rpf'})
        self.assertEqual(len(self.peds.findall('./InitDatas/Item')), 19)
        self.assertEqual(len(self.vehicles.findall('./InitDatas/Item')), 11)
        # Inspect nested resource archives: all model/texture wrappers stay Legacy.
        resources = 0
        for path in ['x64/models/cdimages/pedcomposition.rpf', 'x64/models/cdimages/pedprops.rpf',
                     'x64/levels/gta5/vehicles/vehicles.rpf']:
            nested = Rpf(self.pack.read(path))
            for name, entry in nested.entries.items():
                if entry['resource']:
                    data = nested.raw(name)
                    self.assertEqual(data[:4], b'RSC7')
                    self.assertIn(struct.unpack_from('<I', data, 4)[0], {2, 13, 162, 165})
                    sf, gf = struct.unpack_from('<II', data, 8)
                    self.assertTrue(all(p >= 8192 for p in pages(sf)+pages(gf)), name)
                    resources += 1
        self.assertGreater(resources, 150)

    def test_06_vehicle_handling_layout_audio_dependencies_are_available(self):
        layouts = ET.parse(ROOT/'base/common/data/ai/vehiclelayouts.meta').getroot()
        handling = ET.parse(ROOT/'base/common/data/handling.meta').getroot()
        stock = ET.parse(ROOT/'base/common/data/levels/gta5/vehicles.meta').getroot()
        layout_names = {x.text.lower() for x in layouts.findall('.//Name') if x.text}
        handling_names = {x.text.lower() for x in handling.findall('.//handlingName')}
        stock_names = {x.text.lower() for x in stock.findall('.//modelName')}
        for item in self.vehicles.findall('./InitDatas/Item'):
            with self.subTest(vehicle=item.findtext('modelName')):
                self.assertIn(item.findtext('layout').lower(), layout_names)
                self.assertIn(item.findtext('handlingId').lower(), handling_names)
                self.assertIn(item.findtext('audioNameHash').lower(), stock_names)
        original = ET.fromstring(self.old.read('common/data/levels/gta5/vehicles.meta'))
        changes = []
        for a, b in zip(original.findall('./InitDatas/Item'), self.vehicles.findall('./InitDatas/Item')):
            self.assertEqual([x.tag for x in a], [x.tag for x in b])
            for x, y in zip(a, b):
                if signature(x) != signature(y): changes.append((a.findtext('modelName'), x.tag))
        self.assertEqual(set(changes), {('ncgpatrolboat', 'handlingId'), ('ncgpatrolboat', 'layout'),
                                      ('ncgpatrolboat', 'audioNameHash'), ('usmarshcruiser', 'audioNameHash'),
                                      ('fibannihilator', 'audioNameHash'), ('ncgannihilator', 'audioNameHash')})

    def test_07_dispatch_keeps_police_expansion_and_has_no_absent_dlc_models(self):
        base = ET.parse(ROOT/'base/common/data/dispatch.meta').getroot()
        base_vehicles = ET.parse(ROOT/'base/common/data/levels/gta5/vehicles.meta').getroot()
        known_vehicles = {x.text.lower() for x in base_vehicles.findall('.//modelName')}
        known_vehicles |= {x.text.lower() for x in self.vehicles.findall('.//modelName')}
        self.assertEqual({x.text.lower() for x in self.dispatch.findall('.//VehicleModels/Vehicle')}-known_vehicles, set())
        known_peds = {x.text.lower() for x in base.findall('.//Ped')}
        known_peds |= {x.text.lower() for x in self.peds.findall('./InitDatas/Item/Name')}
        self.assertEqual({x.text.lower() for x in self.dispatch.findall('.//Ped')}-known_peds, set())
        sets = {x.text for x in self.dispatch.findall('./VehicleSets/Vehicle/Name')}
        wanted = {x.text for x in self.dispatch.findall('./WantedResponses//Dispatch')}
        self.assertTrue({'POLICE_CAR_FIB', 'FIB_JEEP', 'POLICE_HELI_FIB', 'POLICE_CAR_MARSHAL'} <= sets)
        self.assertTrue(wanted <= sets)
        self.assertFalse({'BIKER', 'ASSASSINS'} & sets)

    def test_08_explicit_install_paths_and_unrelated_features_are_preserved(self):
        game_files = {n: d for n, d in self.files.items() if not n.endswith('.txt')}
        self.assertEqual(len(game_files), 8)
        for name in game_files:
            self.assertTrue(name.startswith(('update/update.rpf/', 'update/x64/dlcpacks/')), name)
            self.assertNotIn('backup', name.lower())
            self.assertNotIn('mpHipster', name)
            self.assertNotIn('script_wasm', name)
            self.assertNotIn('weapons.meta', name)
        self.assertEqual(len([n for n in game_files if n.endswith('/loadouts.meta')]), 1)
        self.assertEqual(len([n for n in game_files if n.endswith('/dispatch.meta')]), 1)
        for name, source in [('x64/levels/gta5/popgroups.ymt', 'popgroups.ymt'),
                             ('x64/levels/gta5/zonebind.ymt', 'zonebind.ymt'),
                             ('common/data/levels/gta5/popcycle.dat', 'popcycle.dat')]:
            self.assertEqual(game_files['update/update.rpf/'+name], (AUTHOR/source).read_bytes())
        self.assertEqual(game_files['update/x64/dlcpacks/wsefedmap/dlc.rpf'], (AUTHOR/'wsefedMap/dlc.rpf').read_bytes())
        report = json.loads((ROOT/'output/build-report.json').read_text())
        for name, data in game_files.items():
            self.assertEqual(hashlib.sha256(data).hexdigest(), report['install_files'][name]['sha256'])

    def test_09_execute_real_engine_constructor_old_traps_and_new_passes(self):
        old = Rpf(self.old.read('x64/levels/gta5/vehicles/vehicles.rpf'))
        new = Rpf(self.pack.read('x64/levels/gta5/vehicles/vehicles.rpf'))
        results = []
        for name in ['sepcruiser.yft', 'sepcruiser_hi.yft']:
            with self.subTest(model=name):
                broken = execute(old.raw(name))
                fixed = execute(new.raw(name))
                self.assertFalse(broken['constructor_returned'])
                self.assertIn('unreachable', broken['trap'])
                self.assertTrue(fixed['constructor_returned'])
                self.assertIsNone(fixed['trap'])
                results.append({'model': name, 'original': broken, 'fixed': fixed})
        (ROOT/'output/real-constructor-regression.json').write_text(json.dumps(results, indent=2)+'\n')

    def test_10_only_two_resource_wrappers_change_and_model_payloads_stay_identical(self):
        path = 'x64/levels/gta5/vehicles/vehicles.rpf'
        old, new = Rpf(self.old.read(path)), Rpf(self.pack.read(path))
        self.assertEqual(set(old.entries), set(new.entries))
        changed = {name for name in old.entries if old.raw(name) != new.raw(name)}
        self.assertEqual(changed, {'sepcruiser.yft', 'sepcruiser_hi.yft'})
        for name in changed:
            a, b = old.raw(name), new.raw(name)
            self.assertEqual(a[:8], b[:8])
            old_data, new_data = zlib.decompress(a[16:], -15), zlib.decompress(b[16:], -15)
            self.assertEqual(new_data, old_data+b'\0'*4096)
            sf, gf = struct.unpack_from('<II', b, 8)
            self.assertEqual(new.entries[name]['plain_size'], sf)
            self.assertEqual(new.entries[name]['encrypted'], gf)
            self.assertEqual(len(new_data), sum(pages(sf)+pages(gf)))
            self.assertGreaterEqual(min(pages(sf)), 8192)
            old_info = struct.unpack_from('<Q', old_data, 8)[0]-0x50000000
            self.assertLessEqual(len(pages(sf)+pages(gf)), old_data[old_info+8]+old_data[old_info+9])


if __name__ == '__main__': unittest.main(verbosity=2)
