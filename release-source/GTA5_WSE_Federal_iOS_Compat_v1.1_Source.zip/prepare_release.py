"""Prepare an allowlisted source archive; never package App files or raw user logs."""
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DIST = ROOT/'dist'
SOURCE = DIST/'GTA5_WSE_Federal_iOS_Compat_v1.1_Source.zip'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare():
    files = [ROOT/name for name in [
        'build_compat.py', 'verify_compat.py', 'rpf_open.py', 'resource_pages.py',
        'engine_constructor.py', 'requirements.txt', 'prepare_release.py', '诊断与修复说明.md',
        'output/build-report.json', 'output/verification.log',
        'output/real-constructor-regression.json',
    ]]
    for directory in ['base/common', 'base/x64', 'references', 'engine']:
        files.extend(p for p in (ROOT/directory).rglob('*') if p.is_file())
    if (ROOT/'output/clean-rebuild.json').exists():
        files.append(ROOT/'output/clean-rebuild.json')
    with zipfile.ZipFile(SOURCE, 'w') as z:
        for path in sorted(files):
            info = zipfile.ZipInfo(path.relative_to(ROOT).as_posix(), (2024, 7, 30, 0, 0, 0))
            info.external_attr = 0o100644 << 16
            z.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
    assets = [DIST/'GTA5_WSE_Federal_iOS_Compat_v1.1.zip', SOURCE]
    (DIST/'SHA256SUMS.txt').write_text(''.join(f'{digest(p)}  {p.name}\n' for p in assets))
    print(json.dumps([{'name': p.name, 'bytes': p.stat().st_size, 'sha256': digest(p)}
                      for p in assets], indent=2))


if __name__ == '__main__':
    prepare()
