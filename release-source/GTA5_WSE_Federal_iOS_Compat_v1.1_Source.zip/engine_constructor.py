"""Execute the target game's unchanged pgBase function, with an exact resource page map.

This runs the actual extracted WebAssembly instructions, not a reimplementation of the guard.
Only its external Quitf import is replaced by a failing diagnostic handler. Memory and resource
mapping are constructed from the real RSC7 page flags and uncompressed bytes.
"""
import functools
import struct
import zlib
from pathlib import Path

import wasmtime
from resource_pages import pages


@functools.lru_cache(maxsize=1)
def compiled():
    body = (Path(__file__).resolve().parent/'engine/pgbase-constructor.wat').read_text()
    body = body.replace('(type 0)', '(export "pgBase")', 1)
    wat = '''(module
      (import "env" "quit" (func $Quitf_int__char_const*__..._ (param i64 i64)))
      (memory (export "memory") i64 256)
      (global $__stack_pointer (mut i64) (i64.const 15728640))
      (global $GOT.data.internal.rage::datResource_sm_Current i64 (i64.const 4096))
    '''+body+')'
    config = wasmtime.Config()
    config.wasm_memory64 = True
    config.consume_fuel = True
    engine = wasmtime.Engine(config)
    return engine, wasmtime.Module(engine, wasmtime.wat2wasm(wat))


def execute(raw):
    assert raw[:4] == b'RSC7'
    _, sf, gf = struct.unpack_from('<III', raw, 4)
    system, graphics = pages(sf), pages(gf)
    plain = zlib.decompress(raw[16:], -15)
    assert len(plain) == sum(system)+sum(graphics)
    engine, module = compiled()
    store = wasmtime.Store(engine)
    store.set_fuel(200000)

    def fail_quit(a, b):
        raise AssertionError(('unexpected resource address fixup failure', a, b))

    quit_func = wasmtime.Func(store, wasmtime.FuncType([wasmtime.ValType.i64(), wasmtime.ValType.i64()], []), fail_quit)
    instance = wasmtime.Instance(store, module, [quit_func])
    memory = instance.exports(store)['memory']
    context, mapping, dest = 8192, 16384, 0x100000
    memory.write(store, plain[:sum(system)], dest)
    memory.write(store, plain[sum(system):], 0x800000)
    memory.write(store, struct.pack('<Q', context), 4096)
    memory.write(store, struct.pack('<Q', mapping), context)
    memory.write(store, bytes([len(system), len(graphics), 0]), mapping)
    entries = []
    for sizes, source_base, target_base in [(system, 0x50000000, dest), (graphics, 0x60000000, 0x800000)]:
        offset = 0
        for size in sizes:
            entries.append((source_base+offset, target_base+offset, size))
            offset += size
    for index, (source, target, size) in enumerate(entries):
        memory.write(store, struct.pack('<3Q', source, target, size), mapping+16+24*index)
        memory.write(store, struct.pack('<2Q', source, size | (index << 56)), context+24+16*index)
    memory.write(store, bytes([len(entries)]), context+4120)
    try:
        result = instance.exports(store)['pgBase'](store, dest)
    except wasmtime.Trap as error:
        return {'trap': str(error), 'constructor_returned': False}
    assert result == dest
    relocated = struct.unpack('<Q', memory.read(store, dest+8, dest+16))[0]
    counts = memory.read(store, relocated+8, relocated+10)
    assert list(counts) == [len(system), len(graphics)]
    return {'trap': None, 'constructor_returned': True, 'page_info_counts': list(counts)}
